<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "dbkedai";
    $conn = mysqli_connect ($host,$user,$pass,$db);
    //    pesan eror
    if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

?>